const server = require('./src/index')

server.listen(3001, () => console.log('aguanten las tetas'))